<!DOCTYPE html> 
<html lang="en">
<?php 
session_start();
include('./db_connect.php');
ob_start();
if(!isset($_SESSION['system'])){
	$system = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach($system as $k => $v){
		$_SESSION['system'][$k] = $v;
	}
}
ob_end_flush();

if(isset($_SESSION['login_id']))
header("location:index.php?page=home");
?>

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $_SESSION['system']['name'] ?></title>

<?php include('./header.php'); ?>

<style>

/* 🌈 Animated Gradient Background */
body {
    margin: 0;
    height: 100vh;
    font-family: 'Poppins', sans-serif;
    /*background: linear-gradient(-45deg, #ff4d6d, #6c5ce7, #00cec9, #0984e3); */
    background: url('assets/uploads/right.png') no-repeat center;
    background-size: 130% 180%;
    animation: gradientBG 10s ease infinite;
}

@keyframes gradientBG {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* 🔲 Layout */
#main {
    display: flex;
    height: 100vh;
}

/* 🖼 Left Side */
#login-left {
    width: 60%;
    background: url('assets/uploads/bg.jpg') no-repeat center;
    background-size: cover;
    position: relative;
}

#login-left::after {
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
}

/* 🔐 Right Side */
#login-right {
    width: 40%;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* 🧊 Glass Card */
.card {
    width: 100%;
    max-width: 380px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    border: none;
    box-shadow: 0 8px 30px rgba(0,0,0,0.3);
    animation: fadeIn 1s ease;
}

/* ✨ Animation */
@keyframes fadeIn {
    from {opacity: 0; transform: translateY(20px);}
    to {opacity: 1; transform: translateY(0);}
}

/* 🏷 Title */
.system-title {
    color: #fff;
    text-align: center;
    font-weight: 600;
    margin-bottom: 20px;
}

/* ✏ Inputs */
.form-control {
    border-radius: 25px;
    padding: 10px 15px;
    border: none;
    margin-bottom: 10px;
}

/* 🔘 Button */
.btn-primary {
    border-radius: 25px;
    background: linear-gradient(45deg, #ff4d6d, #6c5ce7);
    border: none;
    transition: 0.3s;
}

.btn-primary:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 20px rgba(0,0,0,0.3);
}

/* ⚠ Error */
.alert {
    border-radius: 10px;
    font-size: 14px;
}

/* 📱 Responsive */
@media (max-width: 768px) {
    #login-left {
        display: none;
    }
    #login-right {
        width: 100%;
    }
}

</style>
</head>

<body>

<main id="main">

    <!-- Left Image -->
    <div id="login-left"></div>

    <!-- Right Login -->
    <div id="login-right">
        <div class="w-100 px-3">

            <h3 class="system-title">
                <?php echo $_SESSION['system']['name'] ?>
            </h3>

            <div class="card p-4">
                <div class="card-body">

                    <form id="login-form">
                        

                        <div id="msg"></div>

                        <div class="form-group">
                            <input type="text" name="username" placeholder="👤 Username" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input type="password" name="password" placeholder="🔒 Password" class="form-control" required>
                        </div>

                        <button class="btn btn-primary btn-block">
                            🚀 Login
                        </button>

                    </form> 

                </div>
            </div>

        </div>
    </div>

</main>

</body>

<script>
$('#login-form').submit(function(e){
	e.preventDefault();

	let btn = $(this).find('button');
	btn.attr('disabled', true).html('Logging in...');

	$('#msg').html('');

	$.ajax({
		url:'ajax.php?action=login',
		method:'POST',
		data:$(this).serialize(),
		error:err=>{
			console.log(err);
			btn.removeAttr('disabled').html('Login');
		},
		success:function(resp){
			if(resp == 1){
				location.href ='index.php?page=home';
			}else{
				$('#msg').html('<div class="alert alert-danger text-center">❌ Invalid Username or Password</div>');
				btn.removeAttr('disabled').html('Login');
			}
		}
	});
});
</script>

</html>