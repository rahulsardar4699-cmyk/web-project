
<style>
	.collapse a{
		text-indent:10px;
	}
	nav#sidebar{
		/*background: url(assets/uploads/<?php echo $_SESSION['system']['cover_img'] ?>) !important*/
	}
	#sidebar {
		width: 240px;
		height: 100vh;
		position: fixed;
		background: linear-gradient(180deg, #d32f2f, #b71c1c);
		padding-top: 20px;
		transition: all 0.3s ease;
		box-shadow: 4px 0 15px rgba(0,0,0,0.1);
	}

	/* Sidebar Items */
	.sidebar-list a {
		display: flex;
		align-items: center;
		padding: 12px 20px;
		margin: 5px 10px;
		color: #fff;
		text-decoration: none;
		border-radius: 10px;
		font-size: 15px;
		transition: all 0.3s ease;
		position: relative;
		overflow: hidden;
	}

	/* Icons */
	.sidebar-list a i {
		margin-right: 10px;
		font-size: 16px;
		transition: 0.3s;
	}

	/* Hover Effect */
	.sidebar-list a:hover {
		background: rgba(255,255,255,0.15);
		transform: translateX(6px);
	}

	.sidebar-list a:hover i {
		transform: scale(1.2);
	}

	/* Active Menu */
	.sidebar-list a.active {
		background: #fff;
		color: #d32f2f;
		font-weight: 600;
		box-shadow: 0 4px 10px rgba(0,0,0,0.2);
	}

	.sidebar-list a.active i {
		color: #d32f2f !important;
	}

	/* Smooth indicator line */
	.sidebar-list a::before {
		content: "";
		position: absolute;
		left: 0;
		top: 0;
		height: 100%;
		width: 4px;
		background: #fff;
		transform: scaleY(0);
		transition: 0.3s;
	}

	.sidebar-list a:hover::before {
		transform: scaleY(1);
	}

	.sidebar-list a.active::before {
		transform: scaleY(1);
		background: #d32f2f;
	}

	/* Collapse Animation */
	.collapse a {
		padding-left: 40px;
		font-size: 14px;
		transition: 0.3s;
	}

	/* Scrollbar (optional modern look) */
	#sidebar::-webkit-scrollbar {
		width: 5px;
	}
	#sidebar::-webkit-scrollbar-thumb {
		background: rgba(255,255,255,0.3);
		border-radius: 10px;
	}
</style>

<nav id="sidebar" class='mx-lt-5 bg-danger' >
		
		<div class="sidebar-list">
				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home text-danger"></i></span> Home</a>
				<a href="index.php?page=donors" class="nav-item nav-donors"><span class='icon-field'><i class="fa fa-user-friends text-danger"></i></span> Donors</a>
				<a href="index.php?page=donations" class="nav-item nav-donations"><span class='icon-field'><i class="fa fa-tint text-danger"></i></span> Blood Donations</a>
				<a href="index.php?page=requests" class="nav-item nav-requests"><span class='icon-field'><i class="fa fa-th-list text-danger"></i></span> Requests</a>
				<a href="index.php?page=handedovers" class="nav-item nav-handedovers"><span class='icon-field'><i class="fa fa-toolbox text-danger"></i></span> Handed Over</a>
				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users text-danger"></i></span> Users</a>
				<!-- <a href="index.php?page=site_settings" class="nav-item nav-site_settings"><span class='icon-field'><i class="fa fa-cogs text-danger"></i></span> System Settings</a> -->
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav_collapse').click(function(){
		console.log($(this).attr('href'))
		$($(this).attr('href')).collapse()
	})
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
