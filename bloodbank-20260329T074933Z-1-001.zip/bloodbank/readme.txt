
About
The Blood Bank Management System is a simple PHP/MySQLi project that manages blood inventory in a certain blood bank. The system only allows the blood bank's management to access the data because the system focuses only on the data management or the inventory of the blood availability in a certain blood bank. This system stores the list of donors, blood donations, requests and handed over requested blood. The blood donations list in this system will serve as the receiving or the process where we can update the volume availability of blood in each blood group. The requested feature in this system will serve as the record of requested blood for a certain patient, which is requesting for specific blood with a specific volume data will be submitted ord inputted in this process. The handed over list are the records of handed over blood request, which means in this process updates the available volume of each blood group.

Features
Login Page
The page where the system users will submit their system credentials to access the system data.
Home Page
​​​​​​​The page where the system users will be redirected after logging into the blood bank management system. This page displays the available volume of each blood group and also displays the system data summary.
Donors Page
​​​​​​​The page where all donors are listed and managed.
Blood Donations Page
​​​​​​​The page where the donated blood is listed and managed. The system feature that updating the available volume of the blood stocks.
Requests Page
​​​​​​​The page where all blood requests are listed and managed.
Handed Over Page
​​​​​​​The page where all given blood or handed over blood requests are listed and managed.
Users Page
​​​​​​​The page where can system admin user manages the list the system users.
How to Run

**LOGIN DETAILS** 

Admin
user: admin
pass: admin123
