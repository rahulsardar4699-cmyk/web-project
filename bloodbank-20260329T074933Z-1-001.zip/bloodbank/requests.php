<?php include('db_connect.php');?>

<style>

/* 🌿 Soft Neumorphism Background */
body {
    font-family: 'Poppins', sans-serif;
    background: #e6ecf3;
}

/* Floating Shapes */
body::before, body::after {
    content: "";
    position: fixed;
    border-radius: 50%;
    z-index: 0;
}

body::before {
    width: 250px;
    height: 250px;
    background: #c7d2fe;
    top: -80px;
    left: -80px;
    filter: blur(80px);
}

body::after {
    width: 250px;
    height: 250px;
    background: #a7f3d0;
    bottom: -80px;
    right: -80px;
    filter: blur(80px);
}

/* Card - Neumorphism */
.card {
    border-radius: 20px;
    background: #e6ecf3;
    box-shadow: 10px 10px 20px #c8d0e7,
                -10px -10px 20px #ffffff;
    border: none;
    position: relative;
    z-index: 1;
    animation: fadeUp 0.6s ease;
}

/* Header */
.card-header {
    background: transparent;
    border-bottom: none;
    font-size: 1.4rem;
    font-weight: 600;
    color: #334155;
}

/* Table */
.table {
    background: transparent;
}

.table thead {
    background: #dbeafe;
    border-radius: 10px;
}

.table-hover tbody tr {
    transition: all 0.25s ease;
}

.table-hover tbody tr:hover {
    background: #f1f5f9;
    transform: scale(1.01);
}

/* Buttons */
.btn {
    border-radius: 10px;
    font-weight: 500;
    transition: 0.3s;
}

/* New Button Style */
.btn-primary {
    background: #6366f1;
    border: none;
    box-shadow: 4px 4px 10px rgba(0,0,0,0.1);
}

.btn-primary:hover {
    background: #4f46e5;
    transform: translateY(-2px);
}

/* Outline Buttons */
.btn-outline-primary {
    border: 2px solid #6366f1;
    color: #6366f1;
}

.btn-outline-primary:hover {
    background: #6366f1;
    color: #fff;
}

.btn-outline-danger {
    border: 2px solid #ef4444;
    color: #ef4444;
}

.btn-outline-danger:hover {
    background: #ef4444;
    color: #fff;
}

/* Blood Badge */
.blood-badge {
    background: #fee2e2;
    color: #b91c1c;
    padding: 6px 12px;
    border-radius: 20px;
    font-weight: bold;
}

/* Status Badges */
.status-pending {
    background: #fef3c7;
    color: #92400e;
    padding: 6px 12px;
    border-radius: 20px;
}

.status-approved {
    background: #dcfce7;
    color: #166534;
    padding: 6px 12px;
    border-radius: 20px;
}

/* Title */
.page-title {
    font-size: 1.7rem;
    font-weight: bold;
    color: #1e293b;
    margin-bottom: 15px;
}

/* Animation */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Fix spacing */
td {
    vertical-align: middle !important;
}
td p {
    margin: 0;
}

</style>

<div class="container-fluid mt-4">

    <div class="page-title">🧾 Blood Requests</div>

    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
            <span>List of Requests</span>
            <button class="btn btn-primary btn-sm" id="new_request">
                <i class="fa fa-plus"></i> New Entry
            </button>
        </div>

        <div class="card-body">

            <table class="table table-bordered table-hover text-center">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Reference Code</th>
                        <th>Patient</th>
                        <th>Blood</th>
                        <th>Details</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php 
                    $i = 1;
                    $requests = $conn->query("SELECT * FROM requests order by date(date_created) desc ");
                    while($row=$requests->fetch_assoc()):
                    ?>

                    <tr>
                        <td><?php echo $i++ ?></td>

                        <td><?php echo date('M d, Y',strtotime($row['date_created'])) ?></td>

                        <td><b><?php echo $row['ref_code'] ?></b></td>

                        <td><b><?php echo ucwords($row['patient']) ?></b></td>

                        <td>
                            <span class="blood-badge">
                                <?php echo $row['blood_group'] ?>
                            </span>
                        </td>

                        <td style="text-align:left">
                            <p>Volume: <b><?php echo ($row['volume'] / 1000).' L' ?></b></p>
                            <p>Doctor: <b><?php echo ucwords($row['physician_name']) ?></b></p>
                        </td>

                        <td>
                            <?php if($row['status'] == 0): ?>
                                <span class="status-pending">Pending</span>
                            <?php else: ?>
                                <span class="status-approved">Approved</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <button class="btn btn-sm btn-outline-primary edit_request" data-id="<?php echo $row['id'] ?>">
                                Edit
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete_request" data-id="<?php echo $row['id'] ?>">
                                Delete
                            </button>
                        </td>
                    </tr>

                    <?php endwhile; ?>
                </tbody>

            </table>

        </div>
    </div>

</div>

<script>
$(document).ready(function(){
    $('table').DataTable();
})

$('#new_request').click(function(){
    uni_modal("New Request","manage_request.php","mid-large")
})

$('.edit_request').click(function(){
    uni_modal("Manage Request","manage_request.php?id="+$(this).attr('data-id'),"mid-large")
})

$('.delete_request').click(function(){
    _conf("Are you sure to delete this request?","delete_request",[$(this).attr('data-id')])
})

function delete_request($id){
    start_load()
    $.ajax({
        url:'ajax.php?action=delete_request',
        method:'POST',
        data:{id:$id},
        success:function(resp){
            if(resp==1){
                alert_toast("Deleted successfully",'success')
                setTimeout(function(){
                    location.reload()
                },1200)
            }
        }
    })
}
</script>