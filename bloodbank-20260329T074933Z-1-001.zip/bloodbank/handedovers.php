<?php include('db_connect.php');?>

<style>
	body{
		background: #f4f6f9;
	}

	.card {
		border: none;
		border-radius: 12px;
		box-shadow: 0 4px 20px rgba(0,0,0,0.08);
		transition: 0.3s ease;
		overflow: hidden;
	}

	.card:hover {
		transform: translateY(-4px);
		box-shadow: 0 10px 30px rgba(0,0,0,0.15);
	}

	.card-header {
	background: linear-gradient(45deg, #28a745, #00c851);
	color: #fff;
	padding: 15px 20px;
	border-radius: 12px 12px 0 0;

	/* FIX HEIGHT ISSUE */
	min-height: auto !important;
	height: auto !important;
}

.card-header h5 {
	margin: 0;
	font-weight: 600;
}

.card-header .btn {
	white-space: nowrap; /* 🔥 prevents vertical text */
}

	.table {
		border-radius: 10px;
		overflow: hidden;
	}

	.table thead {
		background: #28a745;
		color: #fff;
	}

	.table tbody tr {
		transition: all 0.3s ease;
	}

	.table tbody tr:hover {
		background: #f1fff5;
		transform: scale(1.01);
	}

	td {
		vertical-align: middle !important;
	}

	td p {
		margin: 0;
		font-weight: 500;
	}

	/* Info block style */
	.info-box {
		background: #f8f9fa;
		padding: 8px 10px;
		border-radius: 8px;
		margin-bottom: 5px;
		transition: 0.3s;
	}

	.info-box:hover {
		background: #e9f7ef;
	}

	/* Buttons */
	.btn {
		border-radius: 20px;
		transition: all 0.3s ease;
	}

	.btn:hover {
		transform: scale(1.08);
		box-shadow: 0 4px 12px rgba(0,0,0,0.2);
	}

	.btn-primary {
		background: linear-gradient(45deg, #28a745, #00c851);
		border: none;
	}

	.btn-outline-primary:hover {
		background: #28a745;
		color: #fff;
	}

	.btn-outline-danger:hover {
		background: #dc3545;
		color: #fff;
	}

	/* Fade Animation */
	.fade-in {
		animation: fadeIn 0.5s ease-in-out;
	}

	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}
</style>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row mb-4 mt-4">
			<div class="col-md-12">
				
			</div>
		</div>
		<div class="row">
			<!-- FORM Panel -->

			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<b>List of Handed Over Requests</b>
						<span class="float:right"><a class="btn btn-primary btn-block btn-sm col-sm-2 float-right" href="javascript:void(0)" id="new_handover">
					<i class="fa fa-plus"></i> New Entry
				</a></span>
					</div>
					<div class="card-body">
						<table class="table table-condensed table-bordered table-hover">
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="">Date</th>
									<th class="">Request's Ref. Code</th>
									<th class="">Patient Name</th>
									<th class="">Blood Group</th>
									<th class="">Information</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$handovers = $conn->query("SELECT hr.*,r.patient,r.blood_group, r.volume,r.ref_code FROM handedover_request hr inner join requests r on r.id = hr.request_id order by date(hr.date_created) desc ");
								while($row=$handovers->fetch_assoc()):
									
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td>
										<?php echo date('M d, Y',strtotime($row['date_created'])) ?>
									</td>
									<td class="">
										 <p> <b><?php echo $row['ref_code'] ?></b></p>
									</td>
									<td class="">
										 <p> <b><?php echo ucwords($row['patient']) ?></b></p>
									</td>
									<td class="">
										 <p> <b><?php echo $row['blood_group'] ?></b></p>
									</td>
									<td class="">
										 <p>Volume Given: <b><?php echo  ($row['volume'] / 1000).' L' ?></b></p>
										 <p>Received By: <b><?php echo ucwords($row['picked_up_by']) ?></b></p>
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-outline-primary edit_handover" type="button" data-id="<?php echo $row['id'] ?>" >Edit</button>
										<button class="btn btn-sm btn-outline-danger delete_handover" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin: unset
	}
	img{
		max-width:100px;
		max-height: :150px;
	}
</style>
<script>
	$(document).ready(function(){
		$('table').dataTable()
	})
	
	$('#new_handover').click(function(){
		uni_modal("New handover","manage_handover.php","mid-large")
		
	})
	$('.edit_handover').click(function(){
		uni_modal("Manage handover Details","manage_handover.php?id="+$(this).attr('data-id'),"mid-large")
		
	})
	$('.delete_handover').click(function(){
		_conf("Are you sure to delete this handover?","delete_handover",[$(this).attr('data-id')])
	})
	
	function delete_handover($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_handover',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>