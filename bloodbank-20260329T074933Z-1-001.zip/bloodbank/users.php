<?php ?>
<style>
/* 🌈 Animated Gradient Background */
body {
    background: linear-gradient(-45deg, #4f46e5, #06b6d4, #22c55e, #9333ea);
    background-size: 400% 400%;
    animation: gradientBG 10s ease infinite;
    font-family: 'Poppins', sans-serif;
}

@keyframes gradientBG {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* 📦 Glass Card */
.card {
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    border: none;
    box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

/* 🧾 Table Styling */
table {
    background: white;
    border-radius: 10px;
    overflow: hidden;
}

thead {
    background: #4f46e5;
    color: white;
}

th, td {
    padding: 12px !important;
    text-align: center;
}

tbody tr {
    transition: 0.3s;
}

tbody tr:hover {
    background: #f1f5f9;
    transform: scale(1.01);
}

/* 🔘 Buttons */
.btn-primary {
    background: linear-gradient(45deg, #4f46e5, #06b6d4);
    border: none;
    border-radius: 25px;
    padding: 6px 15px;
    transition: 0.3s;
}

.btn-primary:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}

/* ➕ New User Button */
#new_user {
    border-radius: 30px;
    padding: 8px 20px;
    font-weight: 600;
}

/* 🎯 Dropdown */
.dropdown-menu {
    border-radius: 10px;
    overflow: hidden;
}

/* 📱 Responsive */
@media (max-width: 768px) {
    table {
        font-size: 12px;
    }
}
</style>

<div class="container-fluid mt-4">

    <div class="row mb-3">
        <div class="col-lg-12 text-right">
            <button class="btn btn-primary btn-sm" id="new_user">
                <i class="fa fa-plus"></i> New User
            </button>
        </div>
    </div>

    <div class="row">
        <div class="card col-lg-12 p-3">
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'db_connect.php';
                        $type = array("", "Admin", "Staff", "Alumnus/Alumna");
                        $users = $conn->query("SELECT * FROM users ORDER BY name ASC");
                        $i = 1;
                        while($row = $users->fetch_assoc()):
                        ?>
                        <tr>
                            <td><?php echo $i++ ?></td>
                            <td><?php echo ucwords($row['name']) ?></td>
                            <td><?php echo $row['username'] ?></td>
                            <td>
                                <span class="badge badge-info">
                                    <?php echo $type[$row['type']] ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-primary btn-sm">Action</button>
                                    <button class="btn btn-primary btn-sm dropdown-toggle dropdown-toggle-split" data-toggle="dropdown"></button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item edit_user" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>">✏️ Edit</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item delete_user text-danger" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>">🗑 Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>
$(document).ready(function(){

    $('table').DataTable();

    $('#new_user').click(function(){
        uni_modal('✨ New User','manage_user.php');
    });

    $('.edit_user').click(function(){
        uni_modal('✏️ Edit User','manage_user.php?id=' + $(this).data('id'));
    });

    $('.delete_user').click(function(){
        _conf("Are you sure to delete this user?","delete_user",[$(this).data('id')]);
    });

});

function delete_user(id){
    start_load();
    $.ajax({
        url:'ajax.php?action=delete_user',
        method:'POST',
        data:{id:id},
        success:function(resp){
            if(resp==1){
                alert_toast("✅ User deleted successfully",'success');
                setTimeout(function(){
                    location.reload();
                },1500);
            }
        }
    });
}
</script>