<?php include 'db_connect.php' ?>

<style>
    /* Page Background */
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #0f172a, #1e293b);
    }

    /* Welcome Text */
    .welcome-text {
        font-size: 1.5rem;
        font-weight: 600;
        color: #4f46e5;
        animation: fadeIn 1s ease-in-out;
    }

    /* Card Styling */
    .card {
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: #fff;
    }

    /* Hover Effect */
    .card:hover {
        transform: translateY(-8px) scale(1.02);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }

    /* Gradient Cards */
    .gradient-card {
        background: linear-gradient(135deg, #6366f1, #22c55e);
        color: #fff;
    }

    /* Blood Group Cards */
    .blood-card {
        background: linear-gradient(135deg, #f87171, #ef4444);
        color: #fff;
    }

    /* Icon Styling */
    .summary_icon {
        font-size: 2.5rem;
        opacity: 0.2;
        position: absolute;
        right: 15px;
        top: 10px;
    }

    /* Numbers */
    .card h4 {
        font-size: 2rem;
        font-weight: bold;
    }

    /* Fade Animation */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(15px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Section Title */
    .section-title {
        font-weight: 600;
        color: #1a5ff5ff;
        margin-bottom: 15px;
    }

    /* Smooth grid spacing */
    .row>div {
        animation: fadeIn 0.6s ease-in-out;
    }
</style>

<div class="container-fluid">
    <div class="row mt-4 px-3">
        <div class="col-lg-12">
            <div class="card p-4">

                <!-- Welcome -->
                <div class="welcome-text">
                    👋 Welcome back <?php echo $_SESSION['login_name']; ?>!
                </div>

                <hr>

                <!-- Blood Group Section -->
                <h4 class="section-title">🩸 Available Blood per Group (Liters)</h4>

                <div class="row">
                    <?php
                    $blood_group = array("A+", "B+", "O+", "AB+", "A-", "B-", "O-", "AB-");

                    foreach ($blood_group as $v) {
                        $bg_inn[$v] = 0;
                        $bg_out[$v] = 0;
                    }

                    $qry = $conn->query("SELECT * FROM blood_inventory ");
                    while ($row = $qry->fetch_assoc()) {
                        if ($row['status'] == 1) {
                            $bg_inn[$row['blood_group']] += $row['volume'];
                        } else {
                            $bg_out[$row['blood_group']] += $row['volume'];
                        }
                    }
                    ?>

                    <?php foreach ($blood_group as $v): ?>
                        <div class="col-md-3 mb-4">
                            <div class="card blood-card p-3 position-relative text-center">
                                <span class="summary_icon">
                                    <i class="fa fa-tint"></i>
                                </span>
                                <h5><?php echo $v ?></h5>
                                <h4>
                                    <?php echo ($bg_inn[$v] - $bg_out[$v]) / 1000 ?>
                                </h4>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <hr>

                <!-- Dashboard Stats -->
                <div class="row">

                    <!-- Donors -->
                    <div class="col-md-3 mb-4">
                        <div class="card gradient-card p-3 position-relative text-center">
                            <span class="summary_icon">
                                <i class="fa fa-user-friends"></i>
                            </span>
                            <h4><?php echo $conn->query("SELECT * FROM donors")->num_rows ?></h4>
                            <p>Total Donors</p>
                        </div>
                    </div>

                    <!-- Today Donation -->
                    <div class="col-md-3 mb-4">
                        <div class="card gradient-card p-3 position-relative text-center">
                            <span class="summary_icon">
                                <i class="fa fa-notes-medical"></i>
                            </span>
                            <h4>
                                <?php echo $conn->query("SELECT * FROM blood_inventory where status = 1 and date(date_created) = '" . date('Y-m-d') . "'")->num_rows ?>
                            </h4>
                            <p>Donated Today</p>
                        </div>
                    </div>

                    <!-- Requests -->
                    <div class="col-md-3 mb-4">
                        <div class="card gradient-card p-3 position-relative text-center">
                            <span class="summary_icon">
                                <i class="fa fa-th-list"></i>
                            </span>
                            <h4>
                                <?php echo $conn->query("SELECT * FROM requests where date(date_created) = '" . date('Y-m-d') . "'")->num_rows ?>
                            </h4>
                            <p>Today's Requests</p>
                        </div>
                    </div>

                    <!-- Approved -->
                    <div class="col-md-3 mb-4">
                        <div class="card gradient-card p-3 position-relative text-center">
                            <span class="summary_icon">
                                <i class="fa fa-check"></i>
                            </span>
                            <h4>
                                <?php echo $conn->query("SELECT * FROM requests where date(date_created) = '" . date('Y-m-d') . "' and status = 1")->num_rows ?>
                            </h4>
                            <p>Approved Requests</p>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<script>
    /* Smooth Toast (Optional Enhancement) */
    function showToast(msg) {
        let toast = document.createElement('div');
        toast.innerText = msg;
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.right = '20px';
        toast.style.background = '#4f46e5';
        toast.style.color = '#fff';
        toast.style.padding = '10px 20px';
        toast.style.borderRadius = '8px';
        toast.style.boxShadow = '0 10px 20px rgba(0,0,0,0.2)';
        toast.style.zIndex = '9999';
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
</script>