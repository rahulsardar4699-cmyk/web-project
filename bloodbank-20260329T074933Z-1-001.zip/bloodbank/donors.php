<?php include('db_connect.php');?>

<style>

/* 🔥 Animated Gradient Background */
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(-45deg, #6366f1, #22c55e, #06b6d4, #a855f7);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

/* Background Animation */
@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* Glass Card */
.card {
    border-radius: 15px;
    border: none;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(12px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    color: #fff;
    animation: fadeIn 0.8s ease-in-out;
}

/* Header */
.card-header {
    font-size: 1.3rem;
    font-weight: 600;
    background: transparent;
    border-bottom: 1px solid rgba(255,255,255,0.2);
}

/* Table Styling */
.table {
    color: #fff;
}

.table thead {
    background: rgba(255,255,255,0.1);
}

.table-hover tbody tr:hover {
    background: rgba(255,255,255,0.1);
    transform: scale(1.01);
    transition: 0.2s;
}

/* Buttons */
.btn {
    border-radius: 8px;
    transition: 0.3s;
}

.btn-primary {
    background: #4f46e5;
    border: none;
}

.btn-primary:hover {
    background: #4338ca;
    transform: scale(1.05);
}

.btn-outline-primary {
    color: #fff;
    border-color: #fff;
}

.btn-outline-primary:hover {
    background: #4f46e5;
}

.btn-outline-danger {
    color: #fff;
    border-color: #ef4444;
}

.btn-outline-danger:hover {
    background: #ef4444;
}

/* Fade Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(15px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Title */
.page-title {
    font-size: 1.6rem;
    font-weight: bold;
    color: #fff;
    margin-bottom: 15px;
}

/* Fix alignment */
td {
    vertical-align: middle !important;
}
td p {
    margin: 0;
}

</style>

<div class="container-fluid mt-4">

    <div class="page-title">🩸 Donor Management</div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>List of Donors</span>
            <button class="btn btn-primary btn-sm" id="new_donor">
                <i class="fa fa-plus"></i> New Entry
            </button>
        </div>

        <div class="card-body">
            <table class="table table-bordered table-hover text-center">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Donor</th>
                        <th>Blood Group</th>
                        <th>Information</th>
                        <th>Previous Donation</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php 
                    $i = 1;
                    $donors = $conn->query("SELECT * FROM donors order by name asc ");
                    while($row=$donors->fetch_assoc()):
                        $prev  = $conn->query("SELECT * FROM blood_inventory where status = 1 and donor_id = ".$row['id']." order by date(date_created) desc limit 1 ");
                        $prev = $prev->num_rows > 0 ? $prev->fetch_array()['date_created'] : '';	
                    ?>
                    <tr>
                        <td><?php echo $i++ ?></td>

                        <td>
                            <b><?php echo ucwords($row['name']) ?></b>
                        </td>

                        <td>
                            <span class="badge badge-danger p-2">
                                <?php echo $row['blood_group'] ?>
                            </span>
                        </td>

                        <td style="text-align:left">
                            <p>Email: <b><?php echo $row['email']; ?></b></p>
                            <p>Contact: <b><?php echo $row['contact']; ?></b></p>
                            <p>Address: <b><?php echo $row['address']; ?></b></p>
                        </td>

                        <td>
                            <?php echo !empty($prev) ? date('M d, Y',strtotime($prev)) : '<span class="badge badge-success">New</span>' ?>
                        </td>

                        <td>
                            <button class="btn btn-sm btn-outline-primary edit_donor" data-id="<?php echo $row['id'] ?>">
                                Edit
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete_donor" data-id="<?php echo $row['id'] ?>">
                                Delete
                            </button>
                        </td>
                    </tr>

                    <?php endwhile; ?>
                </tbody>

            </table>
        </div>
    </div>

</div>

<script>
$(document).ready(function(){
    $('table').DataTable();
})

$('#new_donor').click(function(){
    uni_modal("New Donor","manage_donor.php","mid-large")
})

$('.edit_donor').click(function(){
    uni_modal("Manage Donor Details","manage_donor.php?id="+$(this).attr('data-id'),"mid-large")
})

$('.delete_donor').click(function(){
    _conf("Are you sure to delete this donor?","delete_donor",[$(this).attr('data-id')])
})

function delete_donor($id){
    start_load()
    $.ajax({
        url:'ajax.php?action=delete_donor',
        method:'POST',
        data:{id:$id},
        success:function(resp){
            if(resp==1){
                alert_toast("Deleted successfully",'success')
                setTimeout(function(){
                    location.reload()
                },1200)
            }
        }
    })
}
</script>